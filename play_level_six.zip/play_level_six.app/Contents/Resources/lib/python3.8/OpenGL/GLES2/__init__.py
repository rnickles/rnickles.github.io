"""OpenGL.EGL the portable interface to GL environments"""
from OpenGL.raw.GLES2._types import *
from OpenGL.GLES2.VERSION.GLES2_2_0 import *

from OpenGL.GLES2 import vboimplementation as _gles2_implementation
