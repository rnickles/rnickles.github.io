"""OpenGL.EGL the portable interface to GL environments"""
from OpenGL.raw.GLES1._types import *
from OpenGL.GLES1.VERSION.GLES1_1_0 import *
